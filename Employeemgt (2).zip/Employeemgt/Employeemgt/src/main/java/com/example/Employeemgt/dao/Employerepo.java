package com.example.Employeemgt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Employeemgt.Entity.Employee;

public interface Employerepo extends JpaRepository<Employee,Long>{

}
