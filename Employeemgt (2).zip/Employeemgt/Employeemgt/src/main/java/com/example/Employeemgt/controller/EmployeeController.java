package com.example.Employeemgt.controller;

import com.example.Employeemgt.dto.Employeemgtdto;
import com.example.Employeemgt.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public ResponseEntity<List<Employeemgtdto>> getAllEmployees() {
        List<Employeemgtdto> employees = employeeService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employeemgtdto> getEmployeeById(@PathVariable Long id) {
        Employeemgtdto employee = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(employee);
    }

    @PostMapping
    public ResponseEntity<Employeemgtdto> createEmployee(@RequestBody Employeemgtdto employeeDto) {
        Employeemgtdto createdEmployee = employeeService.createEmployee(employeeDto);
        return new ResponseEntity<>(createdEmployee, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employeemgtdto> updateEmployee(@PathVariable Long id, @RequestBody Employeemgtdto employeeDto) {
        Employeemgtdto updatedEmployee = employeeService.updateEmployee(id, employeeDto);
        return ResponseEntity.ok(updatedEmployee);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return new ResponseEntity<>("Employee Deleted",HttpStatus.OK);
    }
}


/*
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.Employeemgt.Entity.Employee;
import com.example.Employeemgt.dto.Employeemgtdto;
import com.example.Employeemgt.service.EmployeeService;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService empservice;

    @RequestMapping("/empdetails")
    public List<Employeemgtdto> getAllEmp() {
        List<Employeemgtdto> employeeDTOs = empservice.getAllEmp();
        return employeeDTOs;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/empdetails")
    public void addEmp(@RequestBody Employeemgtdto empDTO) {
        Employee emp = new Employee();
        emp.setId(empDTO.getId());
        emp.setName(empDTO.getName());
        emp.setRole(empDTO.getrole());
        empservice.addEmp(emp);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "empdetails/{id}")
    public void updateEmp(@PathVariable Long id, @RequestBody Employeemgtdto empDTO) {
        Employee emp = new Employee();
        emp.setId(empDTO.getId());
        emp.setName(empDTO.getName());
        emp.setRole(empDTO.getrole());
        empservice.updateEmp(id, emp);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        empservice.deleteEmployee(id);
    }
}






/*import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employeemgt.Entity.Employee;
import com.example.Employeemgt.service.EmployeeService;

@CrossOrigin(origins = "http://localhost:3001")
@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService empservice;
     
	@RequestMapping("/empdetails")
	public List<Employee> getAllEmp(){
		return empservice.getAllEmp();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/empdetails")
	public void addEmp(@RequestBody Employee emp) {
		empservice.addEmp(emp);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="empdetails/{id}")
	public void updateEmp(@PathVariable Long id,@RequestBody Employee emp) {
		empservice.updateEmp(id, emp);
	}
	
	 @DeleteMapping("/{id}")
	    public void deleteEmployee(@PathVariable Long id) {
	        empservice.deleteEmployee(id);
		
	}
}
*/
