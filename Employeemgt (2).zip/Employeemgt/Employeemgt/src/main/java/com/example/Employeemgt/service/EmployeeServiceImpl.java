package com.example.Employeemgt.service;

import com.example.Employeemgt.Entity.Employee;
import com.example.Employeemgt.dao.Employerepo;
import com.example.Employeemgt.dto.Employeemgtdto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final Employerepo employerepo;

    @Autowired
    public EmployeeServiceImpl(Employerepo employerepo) {
        this.employerepo = employerepo;
    }

    @Override
    public List<Employeemgtdto> getAllEmployees() {
        List<Employee> employees = employerepo.findAll();
        return employees.stream()
                .map(employee -> {
                    Employeemgtdto employeeDto = new Employeemgtdto();
                    BeanUtils.copyProperties(employee, employeeDto);
                    return employeeDto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public Employeemgtdto getEmployeeById(Long id) {
        Employee employee = employerepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        Employeemgtdto employeeDto = new Employeemgtdto();
        BeanUtils.copyProperties(employee, employeeDto);
        return employeeDto;
    }

    @Override
    public Employeemgtdto createEmployee(Employeemgtdto employeeDto) {
        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDto, employee);
        employerepo.save(employee);
        return employeeDto;
    }

    @Override
    public Employeemgtdto updateEmployee(Long id, Employeemgtdto employeeDto) {
        Employee existingEmployee = employerepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        BeanUtils.copyProperties(employeeDto, existingEmployee);
        employerepo.save(existingEmployee);
        return employeeDto;
    }

    @Override
    public void deleteEmployee(Long id) {
        employerepo.deleteById(id);
    }
}
