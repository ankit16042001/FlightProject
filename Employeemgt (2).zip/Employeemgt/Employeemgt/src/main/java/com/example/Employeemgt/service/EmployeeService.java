package com.example.Employeemgt.service;

import com.example.Employeemgt.dto.Employeemgtdto;

import java.util.List;

public interface EmployeeService {

    List<Employeemgtdto> getAllEmployees();

    Employeemgtdto getEmployeeById(Long id);

    Employeemgtdto createEmployee(Employeemgtdto employeeDto);

    Employeemgtdto updateEmployee(Long id, Employeemgtdto employeeDto);

    void deleteEmployee(Long id);
}

