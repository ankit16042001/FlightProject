package com.example.Flightmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
