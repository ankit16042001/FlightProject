package com.example.Flightmanagementsystem.Service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Flightmanagementsystem.Dao.FlightRepository;
import com.example.Flightmanagementsystem.Dto.FlightDto;
import com.example.Flightmanagementsystem.Entity.Flight;

@Service
public class FlightService implements FlightInterface {

	private final FlightRepository flightRepository;
	@Autowired
	public FlightService (FlightRepository flightRepository) {
		this.flightRepository = flightRepository;
	}

	@Override
	public List<FlightDto> getallflights() {
		List<Flight> flights = flightRepository.findAll();
        return flights.stream()
              .map(flight -> {
            	  FlightDto flightDto = new FlightDto();
                  BeanUtils.copyProperties(flight, flightDto);
                  return flightDto;
              })
              .collect(Collectors.toList());
	}
		

	@Override
	public FlightDto getflightbyid(Long id) {
		Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Flight not found"));
    	FlightDto flightDto = new FlightDto();
        BeanUtils.copyProperties(flight, flightDto);
        return flightDto;
    }
	

	@Override
	public FlightDto createFlight(FlightDto flightDto) {
		Flight flight = new Flight();
        BeanUtils.copyProperties(flightDto, flight);
        flightRepository.save(flight);
        return flightDto;
    }
	

	@Override
	public FlightDto updateFlight(Long id, FlightDto flightDto) {
		Flight existingflight = flightRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Flight not found"));

        BeanUtils.copyProperties(flightDto, existingflight);
        flightRepository.save(existingflight);
        return flightDto;
	}

	@Override
	public void deleteflight(Long id) {
		flightRepository.deleteById(id);
		
	}

	






}
