package com.example.Flightmanagementsystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.Flightmanagementsystem.Dto.FlightDto;
import com.example.Flightmanagementsystem.Service.FlightService;



@CrossOrigin(origins = "http://localhost:3007")
@RestController

public class FlightController {
	@Autowired
	private final FlightService flightService;
	public FlightController(FlightService flightService) {
		this.flightService = flightService;
		
	}
	@GetMapping("/api/flights")
	public ResponseEntity<List<FlightDto>> getAllflights() {
        List<FlightDto> flights = flightService.getallflights();
        return ResponseEntity.ok(flights);
    }
	 @GetMapping("/api/flights/{id}")
	    public ResponseEntity<FlightDto> getFlightById(@PathVariable Long id) {
		 FlightDto flight = flightService.getflightbyid(id);
	        return ResponseEntity.ok(flight );
	    }

	    @PostMapping("/api/flights")
	    public ResponseEntity<FlightDto> createFlight(@RequestBody FlightDto flightDto) {
	    	FlightDto createdFlight = flightService.createFlight(flightDto);
	        return new ResponseEntity<>(createdFlight, HttpStatus.CREATED);
	    }

	    @PutMapping("/api/flights/{id}")
	    public ResponseEntity<FlightDto> updateFlight(@PathVariable Long id, @RequestBody FlightDto flightDto) {
	    	FlightDto updatedFlight = flightService.updateFlight(id, flightDto);
	        return ResponseEntity.ok(updatedFlight);
	    }

	    @DeleteMapping("/api/flights/{id}")
        public ResponseEntity<String> deleteFlight(@PathVariable Long id) {
	    	flightService.deleteflight(id);
	        return new ResponseEntity<>("Flight Deleted",HttpStatus.OK);
	    }
	

		
	}
	





