package com.example.Flightmanagementsystem.Service;

import java.util.List;

import com.example.Flightmanagementsystem.Dto.FlightDto;


public interface FlightInterface {
	List<FlightDto>getallflights();
	FlightDto getflightbyid(Long id);
	FlightDto createFlight(FlightDto flightDto);
	FlightDto updateFlight(Long id, FlightDto flightDto);
	 
	void deleteflight(Long id);

}
