package com.example.Flightmanagementsystem.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flight")
public class Flight {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	private String airline;
	private String departureairport;
	private String arrivalairport;
	private long departuredate;
	private long arrivaldate;
	private double ticketprice;
	public Flight(long id, String airline, String departureairport, String arrivalairport, long departuredate,
			long arrivaldate, double ticketprice) {
		super();
		this.id = id;
		this.airline = airline;
		this.departureairport = departureairport;
		this.arrivalairport = arrivalairport;
		this.departuredate = departuredate;
		this.arrivaldate = arrivaldate;
		this.ticketprice = ticketprice;
	}
	public Flight() {
		super();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepartureairport() {
		return departureairport;
	}
	public void setDepartureairport(String departureairport) {
		this.departureairport = departureairport;
	}
	public String getArrivalairport() {
		return arrivalairport;
	}
	public void setArrivalairport(String arrivalairport) {
		this.arrivalairport = arrivalairport;
	}
	public long getDeparturedate() {
		return departuredate;
	}
	public void setDeparturedate(long departuredate) {
		this.departuredate = departuredate;
	}
	public long getArrivaldate() {
		return arrivaldate;
	}
	public void setArrivaldate(long arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	public double getTicketprice() {
		return ticketprice;
	}
	public void setTicketprice(double ticketprice) {
		this.ticketprice = ticketprice;
	}
	
	

}
