
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import CustomNavbar from './components/Navbar';
import Employees from './components/Employees';
import AddEmployee from './components/AddEmployee'; // Import the new component
import DelEmployee from './components/DelEmployee';
import UpdateEmployee from './components/UpdateEmployee';

function App() {
  return (
    <Router>
      <div className="App">
        <CustomNavbar />
        <div className="container">
          <Routes>
            <Route path="/employees" element={<Employees />} />
            <Route path="/add" element={<AddEmployee />} /> 
            <Route path="/del" element={<DelEmployee/>} />
            <Route path="/update" element={<UpdateEmployee/>} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
