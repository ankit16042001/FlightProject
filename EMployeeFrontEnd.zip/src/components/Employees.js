import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Employees() {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    
    axios.get('http://localhost:8000/employees')
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error('Error fetching employee data:', error);
      });
  }, []);

  return (
    <div>
      <h2 className="text-center" >Employee List</h2>
        <table className="table table-striped">
          <thead>
            <tr>
              <td>EMPLOYEE ID</td>
              <td>EMPLOYEE NAME</td>
              <td>EMPLOYEE ROLE</td>
            </tr>
          </thead>
          <tbody>
        {employees.map((employee => (
         // <li key={employee.id}>{employee.name} - {employee.role}</li>
         <tr>
          <td>{employee.id}</td>
          <td>{employee.name}</td>
          <td>{employee.role}</td>
         </tr>
        ))
        )}
        </tbody>
      </table>
      <Link to="/add" className="btn btn-primary">Add Employee</Link>
      <Link to="/del" className="btn btn-primary">Delete Employee</Link>
      <Link to="/update" className="btn btn-primary">Update Employee</Link>
    </div>
  );
}

export default Employees;
