import React ,{useState,useEffect} from 'react';
import axios from 'axios';
import Link from 'react-router-dom';


function Employeetest(){
 
    const[employees,setEmployee]=useState([]);

    useEffect(() =>{
         axios.get(`http://localhost:8000`)
         .then((response =>{
            setEmployee(response.data);
         }))
         .catch((error) =>{
            console.error(error);
         })
        },[]);

        return(
            <div>
                       <h2 className="text-center">Employees List</h2>
                       <table className="table table-striped">
                        <thead>
                            <td>
                                <tr>Employee id</tr>
                                <tr>Employee name</tr>
                            </td>
                        </thead>
                        <tbody>
                            {employees.map(employee =>(
                                <tr>
                                    <td>{employee.id}</td>
                                    <td>{employee.name}</td>
                                </tr>
                            ))}
                        </tbody>
                       </table>

                    <Link to="/add" className="btn btn-primary">Add student</Link>
            
            </div>
        )

}